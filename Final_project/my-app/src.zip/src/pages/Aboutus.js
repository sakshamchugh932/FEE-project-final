import React from 'react'
import Header from '../componenet/Header'
import Navbar from '../componenet/Navbar'
import About from '../componenet/About'
import Footer1 from '../componenet/Footer1'
import Footer from '../componenet/Footer'

function Aboutus() {
  return (
    <div>
        <Header/>
        <Navbar/>
        <About/>
        <Footer1/>
        <Footer/>
    </div>
  )
}

export default Aboutus;