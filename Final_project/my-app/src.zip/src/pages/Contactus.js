import React from 'react'
import Header from '../componenet/Header'
import Navbar from '../componenet/Navbar'
import Contact from '../componenet/Contact'
import Footer from '../componenet/Footer'
import Footer1 from '../componenet/Footer1'

function Contactus() {
  return (
    <div>
    <Header/>
    <Navbar/>
    <Contact/>
    <Footer1/>
    <Footer/>
    </div>
  )
}

export default Contactus